import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.*;
@WebServlet("/firstservlet")
public class firstservlet extends HttpServlet
{
public void doGet(HttpServletRequest req,HttpServletResponse res)
{
try
{
res.setContentType("text/html");
PrintWriter pw=res.getWriter();
RequestDispatcher rd=req.getRequestDispatcher("secondServlet");
rd.forward(req,res);
pw.close();
}
catch(Exception ae)
{}
}
}