package com.example.demo;
import java.util.Scanner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
@SpringBootApplication
public class SpringBootDaimler1Application {
	public static void main(String[] args) {
		ApplicationContext ac=SpringApplication.run(SpringBootDaimler1Application.class, args);
		MyMessage mm=ac.getBean("msg",MyMessage.class);
		mm.welcome();
		System.out.println("Enter two nos");
		Scanner ob=new Scanner(System.in);
		int a=ob.nextInt();
		int b=ob.nextInt();
		System.out.println("The sum is "+mm.sum(a,b));
	}}
