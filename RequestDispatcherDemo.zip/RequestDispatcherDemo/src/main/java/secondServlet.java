import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.*;
@WebServlet("/secondServlet")
public class secondServlet extends HttpServlet
{
public void doGet(HttpServletRequest req,HttpServletResponse res)
{
try
{
res.setContentType("text/html");
PrintWriter pw=res.getWriter();
pw.println("this is second servlet");
String s=req.getParameter("t1");
String t=req.getParameter("t2");
pw.println("the user name is "+s);
pw.println("the password is "+t);
if(s.equals("sandip")&&t.equals("1234"))
	res.sendRedirect("welcome.html");
else
{
	res.sendRedirect("error.jsp");
	}
}
catch(Exception ae)
{}
}
}