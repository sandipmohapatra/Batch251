select s.student_name, d.department_name
from student s
    inner join department d
    on s.city = "Coimbatore"
        and s.department_id = d.department_id
order by s.student_name;
